# Baseball Batting 101 — Remotion + Three.js (1080×1920, 68 s, 30 fps)

## Install & render
```bash
npm install
npm run dev        # Remotion Studio preview (also generates the audio)
npm run render     # -> out/baseball-tutorial.mp4
npm run still      # single test frame -> out/frame.png
```
Requirements: Node 18+, Chrome is downloaded automatically by Remotion.
Rendering uses software WebGL (`--gl=angle`) — expect ~10–30 min on a laptop. Speed up with
`npx remotion render src/index.ts BaseballTutorial out/v.mp4 --gl=angle --concurrency=4`.
If Remotion warns about mismatched versions: `npx remotion upgrade`.

## Files
- `src/timeline.ts`  the edit: shot list, camera A→B, captions/colors, swing "phase" ranges, SFX cues
- `src/poses.ts`     keyframed batter (correct + incorrect), pitcher, soft-toss coach, ball physics
- `src/Humanoid.tsx` procedural player (IK arms/legs, bat, helmet/cap)
- `src/Stadium.tsx`  field, mound, stands, animated crowd, wall, light towers, scoreboard
- `src/Scene.tsx`    ThreeCanvas, lights, camera rig (punch-in + handheld shake), ball + trail
- `src/Overlay.tsx`  captions (white/red/green), chips, slow-mo badge, flash transitions, confetti, end card
- `src/Main.tsx`     composition + audio
- `scripts/generate-audio.mjs` synthesises music + SFX into `public/audio/`

## Customising
- Change any caption/camera/timing in `SHOTS` (timeline.ts). SFX are auto-synced from it.
- Swing phases: 0 stance · .2 load · .38 stride · .52 launch · .62 contact · .78 extension · 1 finish.
- Real music/SFX: put files in `public/audio/` with the same names (script won't overwrite them),
  or use mp3 and change the names in `Main.tsx` / `timeline.ts`.
- Too dark/bright: light intensities in `Scene.tsx`. Heavy render: lower crowd loops in `Stadium.tsx`.
