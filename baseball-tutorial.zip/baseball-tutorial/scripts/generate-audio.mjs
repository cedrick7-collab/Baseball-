// Synthesises royalty-free placeholder audio (no dependencies). Skips if files already exist,
// so you can drop in your own public/audio/music.mp3|wav etc. Use --force to regenerate.
import fs from 'node:fs';
import path from 'node:path';

const SR = 44100;
const dir = path.join(process.cwd(), 'public', 'audio');
fs.mkdirSync(dir, {recursive: true});
if (fs.existsSync(path.join(dir, 'music.wav')) && !process.argv.includes('--force')) { console.log('audio: already present'); process.exit(0); }

let seed = 12345;
const rand = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
const mk = (len, fn) => { const n = Math.floor(len * SR), a = new Float32Array(n); for (let i = 0; i < n; i++) a[i] = fn(i / SR, i); return a; };

function save(name, f32, gain = 0.9) {
  let peak = 0; for (const v of f32) peak = Math.max(peak, Math.abs(v));
  const s = peak > 0 ? gain / peak : 1, buf = Buffer.alloc(44 + f32.length * 2);
  buf.write('RIFF', 0); buf.writeUInt32LE(36 + f32.length * 2, 4); buf.write('WAVEfmt ', 8);
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22); buf.writeUInt32LE(SR, 24);
  buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34); buf.write('data', 36); buf.writeUInt32LE(f32.length * 2, 40);
  for (let i = 0; i < f32.length; i++) buf.writeInt16LE(Math.max(-1, Math.min(1, f32[i] * s)) * 32767, 44 + i * 2);
  fs.writeFileSync(path.join(dir, name), buf);
  console.log('audio: wrote', name);
}

// ---- music: 112 BPM, kick/snare/hats + bass + arpeggio lead ----
const DUR = 70, N = SR * DUR, m = new Float32Array(N);
const bpm = 112, step = 60 / bpm / 4;
const add = (t, buf, g = 1) => { const i0 = Math.floor(t * SR); for (let i = 0; i < buf.length && i0 + i < N; i++) m[i0 + i] += buf[i] * g; };
const kick = mk(0.3, (t) => Math.sin(2 * Math.PI * (45 * t + 110 * (1 - Math.exp(-30 * t)) / 30)) * Math.exp(-t * 8));
const snare = mk(0.22, (t) => (rand() * 2 - 1) * Math.exp(-t * 22) * 0.7 + Math.sin(2 * Math.PI * 185 * t) * Math.exp(-t * 30) * 0.4);
const hat = mk(0.07, (t) => (rand() * 2 - 1) * Math.exp(-t * 80) * 0.3);
const note = (f, len, kind) => mk(len, (t) => {
  const env = Math.min(1, t * 200) * Math.exp(-t * (kind === 'bass' ? 3 : 9));
  return kind === 'bass' ? (Math.sin(2 * Math.PI * f * t) + 0.4 * Math.sin(4 * Math.PI * f * t)) * env : Math.sign(Math.sin(2 * Math.PI * f * t)) * 0.5 * env;
});
const arp = [440, 523.25, 659.25, 523.25, 783.99, 659.25, 523.25, 392];
for (let s = 0; s * step < DUR - 0.3; s++) {
  const t = s * step, st = s % 16, chord = [1, 1, 0.794, 0.891][Math.floor(s / 16) % 4];
  if (st % 4 === 0) add(t, kick, 1);
  if (t > 2.5 && (st === 4 || st === 12)) add(t, snare, 0.8);
  if (st % 2 === 0) add(t, hat, 0.6); else if (t > 5) add(t, hat, 0.3);
  if (t > 0.5 && st % 2 === 0) add(t, note(55 * chord * (st % 8 === 6 ? 2 : 1), step * 1.9, 'bass'), 0.45);
  if (t > 5) add(t, note(arp[st % 8] * chord, step * 1.5, 'lead'), 0.09);
}
save('music.wav', m, 0.85);

// ---- sound effects ----
save('hit.wav', mk(0.5, (t) => (rand() * 2 - 1) * Math.exp(-t * 70) + Math.sin(2 * Math.PI * 180 * t) * Math.exp(-t * 16) * 0.9 + Math.sin(2 * Math.PI * 1500 * t) * Math.exp(-t * 60) * 0.4), 0.95);
let y = 0;
save('whoosh.wav', mk(0.55, (t) => { const u = t / 0.55, a = 0.03 + 0.4 * Math.sin(Math.PI * u); y += a * ((rand() * 2 - 1) - y); return y * Math.pow(Math.sin(Math.PI * u), 2) * 3; }), 0.7);
save('ding.wav', mk(0.7, (t) => (Math.sin(2 * Math.PI * 880 * t) + 0.6 * Math.sin(2 * Math.PI * 1320 * t)) * Math.exp(-t * 6)), 0.6);
save('buzz.wav', mk(0.4, (t) => Math.sign(Math.sin(2 * Math.PI * 110 * t)) * 0.5 * Math.exp(-t * 6) + Math.sin(2 * Math.PI * 82 * t) * Math.exp(-t * 6)), 0.5);
let l1 = 0, l2 = 0;
const crowd = (len, env) => mk(len, (t) => { const x = rand() * 2 - 1; l1 += 0.25 * (x - l1); l2 += 0.02 * (x - l2); return (l1 - l2) * env(t / len); });
save('cheer.wav', crowd(4.5, (u) => Math.pow(Math.sin(Math.PI * Math.min(u * 1.3, 1)), 0.6) * (1 - u * 0.4)), 0.8);
save('crowd.wav', crowd(12, () => 0.7 + 0.3 * Math.sin(seed % 7)), 0.5);
