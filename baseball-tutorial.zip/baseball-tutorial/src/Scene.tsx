import React, {useLayoutEffect} from 'react';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';
import {FPS, Shot, V3} from './timeline';
import {BALL0, BallOpts, PC, TOSS_POS, TOSS_YAW, ball, batter, contactWorld, pitcher, tosser} from './poses';
import {Colors, Humanoid} from './Humanoid';
import {Stadium} from './Stadium';

const BATTER: Colors = {jersey: '#f5f5f5', pants: '#cfd3da', cap: '#d62828', skin: '#e0ac86', glove: '#111'};
const PITCHER: Colors = {jersey: '#2563eb', pants: '#cfd3da', cap: '#1e3a8a', skin: '#c68642', glove: '#7a4a1e'};
const TOSSER: Colors = {jersey: '#f97316', pants: '#374151', cap: '#f97316', skin: '#8d5524', glove: '#7a4a1e'};

const CameraRig: React.FC<{pos: V3; look: V3; fov: number}> = ({pos, look, fov}) => {
  const {camera} = useThree();
  useLayoutEffect(() => {
    const cam = camera as THREE.PerspectiveCamera;
    cam.position.set(...pos); cam.fov = fov; cam.updateProjectionMatrix(); cam.lookAt(look[0], look[1], look[2]);
  });
  return null;
};

const Ball: React.FC<{phase: number; o: BallOpts}> = ({phase, o}) => {
  const p = ball(phase, o), flying = phase > BALL0[o.mode] + 0.08;
  const f = Math.max(0, 1 - Math.abs(phase - PC) / 0.05); // contact flash
  return (
    <>
      <mesh position={p} castShadow><sphereGeometry args={[0.075, 16, 16]} /><meshStandardMaterial color="#fff" emissive="#ffffff" emissiveIntensity={0.5} /></mesh>
      {flying && [1, 2, 3, 4].map((i) => (
        <mesh key={i} position={ball(phase - 0.02 * i, o)}><sphereGeometry args={[0.065 - i * 0.01, 8, 8]} /><meshBasicMaterial color="#fff" transparent opacity={0.35 - i * 0.07} /></mesh>
      ))}
      {o.variant === 'good' && f > 0 && (
        <mesh position={contactWorld(o.ox)}><sphereGeometry args={[0.1 + 0.35 * f, 16, 16]} /><meshBasicMaterial color="#fff2b0" transparent opacity={f * 0.8} /></mesh>
      )}
    </>
  );
};

export const Scene: React.FC<{t: number; frame: number; shot: Shot}> = ({t, frame, shot}) => {
  const u = Math.min(Math.max((t - shot.start) / (shot.end - shot.start), 0), 1);
  const phase = shot.phase[0] + (shot.phase[1] - shot.phase[0]) * u;
  const e = u * u * (3 - 2 * u);
  const A = shot.a, Bc = shot.b ?? shot.a;
  const mix = (a: V3, b: V3): V3 => [a[0] + (b[0] - a[0]) * e, a[1] + (b[1] - a[1]) * e, a[2] + (b[2] - a[2]) * e];

  const compare = shot.mode === 'compare', toss = shot.mode === 'toss';
  const batters = compare ? [{ox: -1.5, variant: 'bad' as const}, {ox: 1.5, variant: 'good' as const}] : [{ox: 0, variant: shot.variant}];
  const mode = toss ? 'toss' : 'pitch';

  let pos = mix(A.pos, Bc.pos), look = mix(A.look, Bc.look), fov = A.fov + (Bc.fov - A.fov) * e;
  if (shot.chase) look = ball(phase, {mode: 'pitch', variant: 'good', hit: shot.hit, ox: 0}); // follow the home run
  const lf = (t - shot.start) * FPS;
  fov *= 1 - 0.12 * Math.pow(Math.max(0, 1 - lf / 7), 2);              // punch-in on every cut
  pos = [pos[0] + Math.sin(t * 9) * 0.01, pos[1] + Math.cos(t * 11) * 0.01, pos[2]]; // hand-held feel

  const pr = pitcher(phase), tr = tosser(phase);
  return (
    <ThreeCanvas width={1080} height={1920} shadows camera={{fov: 40, near: 0.1, far: 700, position: [0, 2, 5]}} gl={{antialias: true}}>
      <color attach="background" args={['#070b1c']} />
      <fog attach="fog" args={['#0a1230', 120, 420]} />
      <CameraRig pos={pos} look={look} fov={fov} />
      <ambientLight intensity={0.55} />
      <hemisphereLight args={['#9db8ff', '#1b3a1b', 1.0]} />
      <directionalLight position={[-14, 34, 22]} intensity={2.6} castShadow shadow-mapSize={[2048, 2048]}
        shadow-camera-left={-14} shadow-camera-right={14} shadow-camera-top={14} shadow-camera-bottom={-14} shadow-camera-near={1} shadow-camera-far={90} shadow-bias={-0.0004} />
      <directionalLight position={[16, 22, -30]} intensity={1.0} color="#cfe0ff" />

      <Stadium frame={frame} plates={compare ? [-1.5, 1.5] : [0]} />

      {batters.map((b, i) => {
        const r = batter(phase, b.variant, t);
        return (
          <group key={i} position={[b.ox - 0.9, 0, 0]} rotation={[0, Math.PI / 2, 0]}>
            <Humanoid k={r.k} lh={r.lh} rh={r.rh} bat={r.bat} c={BATTER} helmet />
          </group>
        );
      })}
      {shot.pitch && !toss && (
        <group position={[0, 0.25, -18.4]}><Humanoid k={pr.k} lh={pr.lh} rh={pr.rh} c={PITCHER} glove /></group>
      )}
      {toss && (
        <>
          <group position={TOSS_POS} rotation={[0, TOSS_YAW, 0]}><Humanoid k={tr.k} lh={tr.lh} rh={tr.rh} c={TOSSER} glove /></group>
          <group position={[-0.5, 0, -6.1]}>
            <mesh position={[0, 1.8, 0]}><planeGeometry args={[6, 3.6, 24, 14]} /><meshBasicMaterial color="#cbd5e1" wireframe transparent opacity={0.6} /></mesh>
            {[-3, 3].map((x) => <mesh key={x} position={[x, 1.8, 0]}><cylinderGeometry args={[0.05, 0.05, 3.6, 8]} /><meshStandardMaterial color="#888" /></mesh>)}
          </group>
        </>
      )}
      {(shot.pitch || toss) && batters.map((b, i) => <Ball key={i} phase={phase} o={{mode, variant: b.variant, hit: shot.hit, ox: b.ox}} />)}
    </ThreeCanvas>
  );
};
