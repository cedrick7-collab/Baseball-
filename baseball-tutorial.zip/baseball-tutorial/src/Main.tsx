import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Scene} from './Scene';
import {Overlay} from './Overlay';
import {DURATION, FPS, SHOTS, sfxEvents} from './timeline';

const SFX = sfxEvents();
const audio = (f: string) => staticFile(`audio/${f}`);

export const BaseballTutorial: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  let idx = SHOTS.findIndex((s) => t >= s.start && t < s.end);
  if (idx < 0) idx = SHOTS.length - 1;
  const shot = SHOTS[idx];
  const total = DURATION * FPS;
  return (
    <AbsoluteFill style={{backgroundColor: '#070b1c'}}>
      <Scene t={t} frame={frame} shot={shot} />
      <Overlay t={t} frame={frame} shot={shot} idx={idx} />
      {/* music bed + stadium ambience */}
      <Audio src={audio('music.wav')} volume={(f) => interpolate(f, [0, 30, total - 60, total], [0, 0.5, 0.5, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})} />
      <Audio src={audio('crowd.wav')} volume={0.22} loop />
      {/* sound effects, synced to the shot list */}
      {SFX.map((e, i) => (
        <Sequence key={i} from={e.f} durationInFrames={e.d}>
          <Audio src={audio(e.file)} volume={e.v} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
