// Procedural animation: hand-authored keyframes, Catmull-Rom interpolated. All values are in
// character-local space (character faces +z, his LEFT is +x, y up, metres).
import {V3} from './timeline';
export type K = Record<string, number>;
export interface Rig { k: K; lh: V3; rh: V3; bat?: {grip: V3; dir: V3} }

const cr = (p0: number, p1: number, p2: number, p3: number, t: number) =>
  0.5 * (2 * p1 + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t + (-p0 + 3 * p1 - 3 * p2 + p3) * t * t * t);
const clamp01 = (x: number) => Math.min(Math.max(x, 0), 1);

function sample(keys: K[], times: number[], p: number): K {
  const x = clamp01(p);
  let i = 0;
  while (i < times.length - 2 && x > times[i + 1]) i++;
  const t = (x - times[i]) / (times[i + 1] - times[i]);
  const a = keys[Math.max(i - 1, 0)], b = keys[i], c = keys[i + 1], d = keys[Math.min(i + 2, keys.length - 1)];
  const o: K = {};
  for (const k in b) o[k] = cr(a[k], b[k], c[k], d[k], t);
  return o;
}

// ---------------- BATTER (right-handed) ----------------
// px/py/pz pelvis, pyaw hips, cyaw shoulders, lean fwd, tilt side, hyaw head WORLD yaw, hpit head pitch,
// hx/hz head shift, lf*/rf* feet, g* bat grip position, byaw/belev bat direction.
const BASE: K = {px: 0, py: 0.84, pz: 0, pyaw: 0, cyaw: 0, lean: 0.25, tilt: 0, hyaw: 1.5, hpit: 0.15, hx: 0, hz: 0,
  lfx: 0.3, lfy: 0, lfz: 0, rfx: -0.3, rfy: 0, rfz: 0, gx: -0.2, gy: 1.5, gz: 0.3, byaw: -1.5, belev: 1.2};
const kf = (o: Partial<K>): K => ({...BASE, ...o});
const T = [0, 0.2, 0.38, 0.52, 0.62, 0.78, 1];
export const PC = 0.62; // contact phase

const GOOD: K[] = [
  kf({}),
  kf({px: -0.06, pyaw: -0.15, cyaw: -0.25, lfy: 0.14, lfx: 0.33, gx: -0.32, gy: 1.55, gz: 0.22, byaw: -1.7, belev: 1.25}),
  kf({pyaw: -0.1, cyaw: -0.3, lfx: 0.52, gx: -0.3, gy: 1.45, gz: 0.2, byaw: -1.6, belev: 1.15, lean: 0.28}),
  kf({px: 0.1, py: 0.82, pyaw: 0.5, cyaw: 0.15, lfx: 0.52, gx: -0.22, gy: 1.3, gz: 0.3, byaw: -1.1, belev: 0.7, lean: 0.3, hyaw: 1.35, hpit: 0.35}),
  kf({px: 0.14, py: 0.82, pyaw: 0.9, cyaw: 0.85, lfx: 0.52, rfx: -0.27, gx: 0.25, gy: 1.1, gz: 0.35, byaw: 0.05, belev: 0.05, lean: 0.28, hyaw: 1.15, hpit: 0.5}),
  kf({px: 0.15, py: 0.82, pyaw: 1.35, cyaw: 1.5, lfx: 0.52, rfx: -0.27, rfy: 0.04, gx: 0.5, gy: 1.35, gz: 0.3, byaw: 1.4, belev: 0.4, lean: 0.15, hyaw: 1.3, hpit: 0.3}),
  kf({px: 0.15, py: 0.82, pyaw: 1.5, cyaw: 1.75, lfx: 0.52, rfx: -0.27, rfy: 0.05, gx: 0.15, gy: 1.55, gz: -0.1, byaw: 2.8, belev: 0.6, lean: 0.05, hyaw: 1.5, hpit: 0.1}),
];
// Mistakes: narrow stance, low hands, lunging, long looping swing, head pulled out, falling forward.
const BAD: K[] = [
  kf({py: 0.95, lfx: 0.15, rfx: -0.15, lean: 0, gx: 0.25, gy: 0.95, gz: 0.5, byaw: 0.5, belev: 0.25}),
  kf({py: 0.95, px: 0.08, lfx: 0.15, rfx: -0.15, lean: 0.1, gx: 0.25, gy: 0.9, gz: 0.5, byaw: 0.3, belev: 0.25}),
  kf({py: 0.9, px: 0.15, lfx: 0.62, rfx: -0.15, lean: 0.35, hx: 0.1, gx: 0.2, gy: 0.95, gz: 0.5, byaw: 0.2, belev: 0.2}),
  kf({py: 0.85, px: 0.3, pyaw: 0.7, cyaw: 0.6, lfx: 0.62, rfx: -0.12, lean: 0.5, hx: 0.2, gx: 0.35, gy: 0.8, gz: 0.8, byaw: -0.5, belev: -0.2, hyaw: 1.7}),
  kf({py: 0.82, px: 0.4, pyaw: 1.0, cyaw: 1.0, lfx: 0.62, rfx: -0.08, lean: 0.55, tilt: -0.25, hx: 0.35, gx: 0.5, gy: 0.65, gz: 0.8, byaw: 0.15, belev: -0.15, hyaw: 2.4, hpit: 0.1}),
  kf({py: 0.8, px: 0.45, pyaw: 1.4, cyaw: 1.7, lfx: 0.7, rfx: -0.05, lean: 0.55, tilt: -0.45, hx: 0.35, gx: 0.5, gy: 0.9, gz: 0.3, byaw: 1.5, belev: 0.3, hyaw: 2.6, hpit: 0}),
  kf({py: 0.78, px: 0.45, pyaw: 1.6, cyaw: 2.0, lfx: 0.75, rfx: 0.05, rfy: 0.12, lean: 0.6, tilt: -0.6, hx: 0.4, gx: 0.3, gy: 1.0, gz: -0.1, byaw: 2.5, belev: 0.1, hyaw: 2.7, hpit: -0.1}),
];

export function batter(phase: number, variant: 'good' | 'bad', t = 0): Rig {
  const k = sample(variant === 'good' ? GOOD : BAD, T, phase);
  if (phase <= 0) { k.py += Math.sin(t * 3) * 0.006; k.gy += Math.sin(t * 3.4) * 0.012; } // idle breathing
  const e = k.belev, y = k.byaw;
  const dir: V3 = [Math.sin(y) * Math.cos(e), Math.sin(e), Math.cos(y) * Math.cos(e)];
  const grip: V3 = [k.gx, k.gy, k.gz];
  const rh: V3 = [grip[0] + dir[0] * 0.14, grip[1] + dir[1] * 0.14, grip[2] + dir[2] * 0.14];
  return {k, lh: grip, rh, bat: {grip, dir}};
}

// batter local -> world. Batter stands at x=-0.9 (+origin), local +z -> world +x, local +x -> world -z (toward pitcher)
export const toWorld = (l: V3, ox = 0): V3 => [ox - 0.9 + l[2], l[1], -l[0]];
export function contactWorld(ox: number): V3 {
  const {bat} = batter(PC, 'good');
  const g = bat!.grip, d = bat!.dir;
  return toWorld([g[0] + d[0] * 0.62, g[1] + d[1] * 0.62, g[2] + d[2] * 0.62], ox);
}

// ---------------- PITCHER (on the mound at z=-18.4, faces +z) ----------------
const PB: K = {px: 0, py: 0.88, pz: 0, pyaw: 0, cyaw: 0, lean: 0.1, tilt: 0, hyaw: 0, hpit: 0, hx: 0, hz: 0,
  lfx: 0.18, lfy: 0, lfz: 0, rfx: -0.18, rfy: 0, rfz: 0, lhx: 0.18, lhy: 1.15, lhz: 0.35, rhx: -0.05, rhy: 1.15, rhz: 0.35};
const pk = (o: Partial<K>): K => ({...PB, ...o});
const PKEYS: K[] = [
  pk({}),
  pk({py: 0.9, lfy: 0.55, lfz: 0.12, lhz: 0.4, rhz: 0.4, lean: 0.05}),
  pk({py: 0.78, pz: 0.35, lfz: 0.8, lfx: 0.2, lhx: 0.35, lhy: 1.35, lhz: 0.9, rhx: -0.4, rhy: 1.45, rhz: -0.4, cyaw: -0.3, lean: 0.02}),
  pk({py: 0.8, pz: 0.55, lfz: 0.8, lfx: 0.2, rfz: 0.1, lean: 0.45, rhx: -0.2, rhy: 1.75, rhz: 0.45, lhx: 0.2, lhy: 1.0, lhz: 0.6, cyaw: 0.35}),
  pk({py: 0.8, pz: 0.65, lfz: 0.8, lfx: 0.2, rfz: 0.2, rfy: 0.2, lean: 0.65, rhx: -0.1, rhy: 1.55, rhz: 0.95, lhx: 0.3, lhy: 0.9, lhz: 0.4, cyaw: 0.5, hpit: 0.2}),
];
const pp = (ph: number) => clamp01((ph + 1) / 0.6); // windup runs phase -1 .. -0.4, release at -0.4
export function pitcher(ph: number): Rig {
  const k = sample(PKEYS, [0, 0.3, 0.6, 0.85, 1], pp(ph));
  return {k, lh: [k.lhx, k.lhy, k.lhz], rh: [k.rhx, k.rhy, k.rhz]};
}
export const pitcherHand = (ph: number): V3 => { const r = pitcher(ph).rh; return [r[0], 0.25 + r[1], -18.4 + r[2]]; };

// ---------------- SOFT-TOSS COACH ----------------
export const TOSS_POS: V3 = [0.7, 0, -1.2];
export const TOSS_YAW = -0.93; // faces the batter
const TB: K = {...PB, py: 0.55, lean: 0.35, lfx: 0.3, lfz: 0.35, rfx: -0.15, rfz: -0.45, lhx: 0.2, lhy: 0.7, lhz: 0.3, rhx: -0.2, rhy: 0.55, rhz: 0.05};
const tk = (o: Partial<K>): K => ({...TB, ...o});
const TKEYS: K[] = [tk({}), tk({rhz: -0.15, rhy: 0.5, lean: 0.4}), tk({rhx: -0.05, rhy: 0.85, rhz: 0.6, lean: 0.3})];
const tp = (ph: number) => clamp01((ph + 0.65) / 0.4); // release at phase -0.25
export function tosser(ph: number): Rig {
  const k = sample(TKEYS, [0, 0.5, 1], tp(ph));
  return {k, lh: [k.lhx, k.lhy, k.lhz], rh: [k.rhx, k.rhy, k.rhz]};
}
export function tosserHand(ph: number): V3 {
  const r = tosser(ph).rh, c = Math.cos(TOSS_YAW), s = Math.sin(TOSS_YAW);
  return [TOSS_POS[0] + r[0] * c + r[2] * s, r[1], TOSS_POS[2] - r[0] * s + r[2] * c];
}

// ---------------- BALL ----------------
export const BALL0 = {pitch: -0.4, toss: -0.25};
const TAU = 1.6; // seconds of ball flight per phase unit
export interface BallOpts { mode: 'pitch' | 'toss'; variant: 'good' | 'bad'; hit?: string; ox: number }
export function ball(phase: number, o: BallOpts): V3 {
  const toss = o.mode === 'toss', b0 = BALL0[o.mode];
  const hand = (ph: number): V3 => { const h = toss ? tosserHand(ph) : pitcherHand(ph); return [h[0] + (toss ? 0 : o.ox), h[1], h[2]]; };
  if (phase < b0) return hand(phase);
  const S = hand(b0), C = contactWorld(o.ox), u = (phase - b0) / (PC - b0);
  if (o.variant === 'bad') { // swing-and-a-miss: ball sails past the plate
    const Tt: V3 = [C[0], C[1] + 0.2, C[2]];
    const p: V3 = [S[0] + (Tt[0] - S[0]) * u, S[1] + (Tt[1] - S[1]) * u, S[2] + (Tt[2] - S[2]) * u];
    if (u > 1) { const tau = (u - 1) * (PC - b0) * TAU; p[1] = Math.max(0.07, p[1] - 4.9 * tau * tau); p[2] = Math.min(p[2], 4.5); }
    return p;
  }
  if (u <= 1) {
    const arc = toss ? 0.9 * 4 * u * (1 - u) : 0;
    return [S[0] + (C[0] - S[0]) * u, S[1] + (C[1] - S[1]) * u + arc, S[2] + (C[2] - S[2]) * u];
  }
  const tau = (phase - PC) * TAU;
  const v = o.hit === 'homerun' ? [3, 16, -40] : toss ? [0.3, 3, -9] : [2.5, 9, -32];
  const stop = toss ? -5.85 : -112; // soft toss ends in the net
  return [C[0] + v[0] * tau, Math.max(0.07, C[1] + v[1] * tau - 4.9 * tau * tau), Math.max(stop, C[2] + v[2] * tau)];
}
