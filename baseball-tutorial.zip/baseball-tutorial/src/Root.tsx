import React from 'react';
import {Composition} from 'remotion';
import {BaseballTutorial} from './Main';
import {DURATION, FPS} from './timeline';

export const Root: React.FC = () => (
  <Composition
    id="BaseballTutorial"
    component={BaseballTutorial}
    durationInFrames={DURATION * FPS}
    fps={FPS}
    width={1080}
    height={1920}
  />
);
