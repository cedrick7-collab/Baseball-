// Shot list = the whole edit. Every shot: time range, camera A->B, batter "phase" range, caption.
// phase: 0 stance, .2 load, .38 stride, .52 launch, .62 CONTACT, .78 extension, 1 finish (>1 = ball flight only)
export type V3 = [number, number, number];
export type Col = 'white' | 'red' | 'green';
export interface Cam { pos: V3; look: V3; fov: number }
export interface Shot {
  start: number; end: number;
  mode: 'single' | 'compare' | 'toss';
  variant: 'good' | 'bad';
  phase: [number, number];
  pitch?: boolean; hit?: 'line' | 'homerun';
  a: Cam; b?: Cam; chase?: boolean;
  text: string; sub?: string; col: Col;
  slow?: boolean; big?: boolean; split?: boolean;
}
export const FPS = 30;
export const DURATION = 68;
export const CHAPTERS: [number, string][] = [
  [0, 'INTRO'], [5, 'BATTING TECHNIQUES'], [25, 'BODY MOVEMENT'], [40, 'PRACTICE DRILLS'], [55, 'FINAL CHECK'],
];

const c = (pos: V3, look: V3, fov = 36): Cam => ({pos, look, fov});
const B: V3 = [-0.9, 1.15, 0]; // batter's body centre (world)
const FRONT = c([3.2, 1.5, 0.7], B, 34);
const BACK = c([-1.7, 1.5, 3.7], [-1.0, 1.3, 0], 30);   // sees back shoulder + hands
const HEAD = c([1.6, 1.75, -1.2], [-0.9, 1.65, 0], 22); // face close-up
const TOP = c([-0.9, 5.8, 0.9], [-0.9, 0.9, 0.1], 34);  // top-down: hips/shoulders
const FEET = c([2.0, 0.8, 2.0], [-0.9, 0.5, 0], 36);
const FEET2 = c([1.7, 0.9, 1.5], [-0.9, 0.55, 0], 34);
const SIDE = c([2.8, 1.6, -2.0], B, 36);
const PITCHVIEW = c([-0.8, 2.0, 7.5], [0, 1.6, -8], 38);

const sh = (start: number, end: number, text: string, col: Col, o: Partial<Shot> = {}): Shot =>
  ({start, end, text, col, mode: 'single', variant: 'good', phase: [0, 0], a: FRONT, ...o});

export const SHOTS: Shot[] = [
  // 1. INTRO 0-5
  sh(0, 2.5, 'BASEBALL BATTING 101', 'white', {sub: 'LEARN TO HIT LIKE A PRO', big: true, pitch: true, phase: [-1, -0.75],
    a: c([-30, 16, 30], [0, 3, -14], 55), b: c([5.5, 2.2, 5.5], B, 38)}),
  sh(2.5, 5, 'BASEBALL BATTING 101', 'white', {sub: 'LEARN TO HIT LIKE A PRO', big: true, pitch: true, phase: [-0.75, -0.4],
    a: c([3.4, 1.4, 1.8], B, 32), b: c([2.4, 1.5, 1.0], [-0.9, 1.3, 0], 28)}),
  // 2. TECHNIQUE 5-25
  sh(5, 7.5, 'TOO NARROW = NO BALANCE', 'red', {variant: 'bad', a: FEET, b: FEET2}),
  sh(7.5, 10, 'FEET SHOULDER-WIDTH APART', 'green', {a: FEET, b: FEET2}),
  sh(10, 12.5, "DON'T HOLD HANDS LOW", 'red', {variant: 'bad', a: BACK, b: c([-1.5, 1.4, 3.2], [-0.9, 1.2, 0], 28)}),
  sh(12.5, 15, 'HANDS BY BACK SHOULDER', 'green', {a: BACK, b: c([-1.5, 1.5, 3.2], [-1.0, 1.4, 0], 28)}),
  sh(15, 18.5, 'WRONG: LONG, LOOPY SWING', 'red', {variant: 'bad', sub: "YOU'LL MISS!", phase: [0, 1], a: FRONT, b: c([2.6, 1.6, 1.5], B, 36)}),
  sh(18.5, 21.5, 'RIGHT: SHORT & DIRECT', 'green', {sub: 'HANDS LEAD THE BAT', phase: [0, 1], a: FRONT, b: c([2.6, 1.6, 1.5], B, 36)}),
  sh(21.5, 25, 'SEE THE BALL, HIT THE BALL', 'white', {pitch: true, phase: [-1, 1], a: PITCHVIEW, b: c([-1.2, 1.9, 5.0], [-0.4, 1.4, -4], 38)}),
  // 3. BODY MOVEMENT 25-40
  sh(25, 29, 'KEEP YOUR HANDS BACK', 'white', {sub: 'KNOB TO THE BALL', slow: true, phase: [0.25, 0.62], a: BACK, b: c([-0.3, 1.4, 3.0], [-0.5, 1.2, 0], 28)}),
  sh(29, 31, "DON'T PULL YOUR HEAD OUT", 'red', {variant: 'bad', pitch: true, phase: [-0.15, 0.8], a: HEAD, b: c([1.8, 1.8, -1.0], [-0.9, 1.6, 0], 24)}),
  sh(31, 33, 'HEAD STILL, EYES ON BALL', 'green', {pitch: true, phase: [-0.15, 0.8], a: HEAD, b: c([1.8, 1.8, -1.0], [-0.9, 1.6, 0], 24)}),
  sh(33, 37, 'HIPS FIRST, THEN SHOULDERS', 'white', {sub: 'ROTATE LIKE A DOOR', slow: true, phase: [0.3, 0.95], a: TOP, b: c([-0.9, 5.2, 1.6], [-0.9, 0.9, 0.1], 34)}),
  sh(37, 38.5, "DON'T FALL FORWARD", 'red', {variant: 'bad', phase: [0.5, 1], a: SIDE}),
  sh(38.5, 40, 'STAY BALANCED', 'green', {phase: [0.5, 1], a: SIDE}),
  // 4. DRILLS 40-55
  sh(40, 44.5, 'SLOW-MOTION REPS', 'white', {slow: true, phase: [0, 0.95], a: c([3.6, 1.5, 2.6], B, 32), b: c([2.4, 1.5, -3.0], B, 32)}),
  sh(44.5, 47.5, 'SOFT TOSS DRILL', 'white', {mode: 'toss', phase: [-0.65, 0.4], a: c([5, 2.2, 1.5], [-0.2, 0.9, -1.8], 42), b: c([4, 1.8, 0.5], [-0.2, 1.0, -2.5], 38)}),
  sh(47.5, 50, 'HANDS THROUGH THE BALL', 'green', {mode: 'toss', phase: [0.2, 1.0], a: c([2.8, 1.5, 0.4], [-0.4, 1.2, -0.4], 30), b: c([2.2, 1.6, -0.6], [-0.4, 1.2, -0.6], 30)}),
  sh(50, 53, 'FINISH YOUR FOLLOW-THROUGH', 'green', {slow: true, phase: [0.62, 1], a: c([2.4, 1.1, 1.2], [-0.9, 1.4, 0], 32), b: c([2.0, 1.4, 0.4], [-0.9, 1.5, 0], 30)}),
  sh(53, 55, 'HANDS HIGH, CHEST TO PITCHER', 'white', {phase: [1, 1], a: c([2.0, 1.4, 0.4], [-0.9, 1.5, 0], 30), b: c([2.6, 1.6, 1.4], B, 36)}),
  // 5. ENDING 55-68
  sh(55, 59.5, 'WRONG VS. RIGHT', 'white', {mode: 'compare', split: true, pitch: true, phase: [-0.7, 1], a: c([0, 2.2, 7.8], [-0.9, 1.1, 0], 50), b: c([0, 1.9, 6.5], [-0.9, 1.1, 0], 46)}),
  sh(59.5, 62, 'RIGHT WINS EVERY TIME', 'green', {mode: 'compare', slow: true, pitch: true, phase: [0.45, 0.85], a: c([-1.6, 1.5, 4.2], [-2.2, 1.2, 0], 40), b: c([1.4, 1.5, 4.2], [0.8, 1.2, 0], 40)}),
  sh(62, 64.5, 'FOCUS. SWING. HIT.', 'white', {pitch: true, hit: 'homerun', phase: [-0.7, 0.9], a: c([3.6, 1.4, 2.0], B, 32), b: c([2.4, 1.6, 1.0], B, 30)}),
  sh(64.5, 68, 'SWING LIKE A PRO!', 'green', {big: true, pitch: true, hit: 'homerun', chase: true, phase: [0.9, 2.3], a: c([6, 2.5, 7], B, 45), b: c([10, 14, -30], B, 50)}),
];

export interface Sfx { f: number; file: string; v: number; d: number }
export const sfxEvents = (): Sfx[] => {
  const out: Sfx[] = [];
  const at = (t: number, file: string, v: number, d = 60) => out.push({f: Math.round(t * FPS), file, v, d});
  SHOTS.forEach((s, i) => {
    if (i > 0) at(s.start, 'whoosh.wav', 0.5, 30);
    if (i > 0 && s.col === 'green') at(s.start + 0.15, 'ding.wav', 0.45);
    if (i > 0 && s.col === 'red') at(s.start + 0.15, 'buzz.wav', 0.35);
    const [p0, p1] = s.phase;
    const when = (p: number) => s.start + ((p - p0) / (p1 - p0)) * (s.end - s.start);
    const has = (p: number) => p0 < p && p < p1;
    if (has(0.5)) at(when(0.5), 'whoosh.wav', 0.45, 30);
    if (has(0.62) && (s.variant === 'good' || s.mode === 'compare')) {
      at(when(0.62), 'hit.wav', 1, 45);
      if (s.hit === 'homerun') at(when(0.62) + 0.1, 'cheer.wav', 0.8, 150);
    }
  });
  return out;
};
