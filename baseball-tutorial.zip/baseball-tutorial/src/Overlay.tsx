import React from 'react';
import {interpolate, spring, useVideoConfig} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Anton';
import {CHAPTERS, Col, DURATION, FPS, SHOTS, Shot} from './timeline';

const {fontFamily} = loadFont();
const FONT = `${fontFamily}, Impact, "Arial Black", sans-serif`;
const COL: Record<Col, string> = {white: '#ffffff', red: '#ff2e2e', green: '#2dff7a'};
const CONFETTI = ['#ff2e2e', '#2dff7a', '#ffd166', '#ffffff', '#4cc9f0', '#f72585'];

const Caption: React.FC<{shot: Shot; idx: number; frame: number}> = ({shot, idx, frame}) => {
  const {fps} = useVideoConfig();
  const lf = frame - Math.round(shot.start * FPS);
  const same = idx > 0 && SHOTS[idx - 1].text === shot.text;
  const s = same ? 1 : spring({frame: lf, fps, config: {damping: 9, stiffness: 190, mass: 0.6}});
  const scale = same ? 1 : 0.45 + 0.55 * s;
  const rot = same ? 0 : (1 - s) * (shot.col === 'red' ? -6 : 4);
  const size = shot.big ? 128 : shot.text.length > 22 ? 88 : 104;
  const chip = shot.col === 'red' ? '✗ MISTAKE' : shot.col === 'green' ? '✓ CORRECT' : null;
  return (
    <div style={{position: 'absolute', left: 40, right: 40, top: shot.big ? 760 : 1130, textAlign: 'center',
      transform: `scale(${scale}) rotate(${rot}deg)`, opacity: same ? 1 : Math.min(1, lf / 3)}}>
      {chip && (
        <div style={{display: 'inline-block', padding: '4px 30px', borderRadius: 16, marginBottom: 12, fontFamily: FONT, fontSize: 50, letterSpacing: 4,
          color: '#fff', background: shot.col === 'red' ? '#ff2e2e' : '#16c860', boxShadow: '0 8px 0 rgba(0,0,0,.5)'}}>{chip}</div>
      )}
      <div style={{fontFamily: FONT, fontSize: size, lineHeight: 1.03, letterSpacing: 2, textTransform: 'uppercase', color: COL[shot.col],
        WebkitTextStroke: '14px #000', paintOrder: 'stroke fill', textShadow: '0 10px 0 rgba(0,0,0,.55)'}}>{shot.text}</div>
      {shot.sub && (
        <div style={{marginTop: 14, fontFamily: FONT, fontSize: 56, letterSpacing: 3, color: '#ffe14d', WebkitTextStroke: '9px #000', paintOrder: 'stroke fill'}}>{shot.sub}</div>
      )}
    </div>
  );
};

const Confetti: React.FC<{t: number}> = ({t}) => {
  if (t < 64.4) return null;
  const tt = t - 64.4;
  return (
    <>
      {Array.from({length: 70}).map((_, i) => {
        const r = (n: number) => ((Math.sin(i * 127.1 + n * 311.7) * 43758.5453) % 1 + 1) % 1;
        return <div key={i} style={{position: 'absolute', left: r(1) * 1080 + Math.sin(tt * 3 + i) * 40, top: -80 - r(2) * 500 + tt * (420 + r(3) * 380),
          width: 18, height: 30, background: CONFETTI[i % 6], transform: `rotate(${tt * (180 + r(4) * 400)}deg)`}} />;
      })}
    </>
  );
};

export const Overlay: React.FC<{t: number; frame: number; shot: Shot; idx: number}> = ({t, frame, shot, idx}) => {
  const {fps} = useVideoConfig();
  const lf = frame - Math.round(shot.start * FPS);
  const flash = idx > 0 ? Math.max(0, 1 - lf / 6) : 0;
  const chapter = [...CHAPTERS].reverse().find(([s]) => t >= s)![1];
  const endT = DURATION - 1.8;
  const end = interpolate(t, [endT, endT + 0.4], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const pulse = 1 + Math.sin(frame / 4) * 0.06;
  return (
    <>
      <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,0,0,.55) 100%)'}} />
      <div style={{position: 'absolute', left: 50, top: 120}}>
        <div style={{display: 'inline-block', padding: '6px 26px', borderRadius: 40, background: '#d62828', color: '#fff', fontFamily: FONT, fontSize: 44, letterSpacing: 3}}>⚾ BASEBALL 101</div>
        <div style={{marginTop: 10, fontFamily: FONT, fontSize: 34, letterSpacing: 5, color: '#ffd166', WebkitTextStroke: '6px #000', paintOrder: 'stroke fill'}}>{chapter}</div>
      </div>
      {shot.slow && (
        <div style={{position: 'absolute', right: 50, top: 124, transform: `scale(${pulse})`, padding: '6px 24px', borderRadius: 14, background: 'rgba(0,0,0,.65)',
          border: '4px solid #4cc9f0', color: '#4cc9f0', fontFamily: FONT, fontSize: 40, letterSpacing: 3}}>▶ SLOW-MO</div>
      )}
      {shot.split && (
        <>
          <div style={{position: 'absolute', left: 539, top: 0, bottom: 0, width: 4, background: 'rgba(255,255,255,.55)'}} />
          <div style={{position: 'absolute', left: 40, top: 300, width: 480, textAlign: 'center', fontFamily: FONT, fontSize: 78, color: COL.red, WebkitTextStroke: '10px #000', paintOrder: 'stroke fill'}}>WRONG ✗</div>
          <div style={{position: 'absolute', left: 560, top: 300, width: 480, textAlign: 'center', fontFamily: FONT, fontSize: 78, color: COL.green, WebkitTextStroke: '10px #000', paintOrder: 'stroke fill'}}>RIGHT ✓</div>
        </>
      )}
      <Caption shot={shot} idx={idx} frame={frame} />
      <Confetti t={t} />
      <div style={{position: 'absolute', inset: 0, background: COL[shot.col], opacity: flash * 0.5}} />
      <div style={{position: 'absolute', left: 40, right: 40, bottom: 60, height: 10, borderRadius: 6, background: 'rgba(255,255,255,.25)'}}>
        <div style={{width: `${(t / DURATION) * 100}%`, height: '100%', borderRadius: 6, background: 'linear-gradient(90deg,#ff2e2e,#ffd166)'}} />
      </div>
      {end > 0 && (
        <div style={{position: 'absolute', inset: 0, background: `rgba(5,8,20,${end * 0.82})`, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', opacity: end}}>
          <div style={{fontSize: 220, transform: `translateY(${Math.abs(Math.sin(frame / 8)) * -60}px) rotate(${frame * 6}deg)`}}>⚾</div>
          <div style={{fontFamily: FONT, fontSize: 170, color: '#fff', WebkitTextStroke: '14px #000', paintOrder: 'stroke fill', letterSpacing: 4}}>BASEBALL 101</div>
          <div style={{fontFamily: FONT, fontSize: 74, color: '#ffe14d', marginTop: 20, WebkitTextStroke: '10px #000', paintOrder: 'stroke fill'}}>PRACTICE EVERY DAY</div>
          <div style={{marginTop: 50, padding: '10px 50px', borderRadius: 24, background: '#16c860', color: '#fff', fontFamily: FONT, fontSize: 64, letterSpacing: 3, transform: `scale(${pulse})`}}>FOLLOW FOR MORE TIPS</div>
        </div>
      )}
    </>
  );
};
