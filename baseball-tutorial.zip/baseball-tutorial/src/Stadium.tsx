import React, {useLayoutEffect, useMemo, useRef} from 'react';
import * as THREE from 'three';

const CZ = -35, RX = 80, RZF = 70, RZB = 52, N = 96;
const rng = (seed: number) => () => {
  seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
// point on the stadium ellipse at angle th, pushed outward by d metres
function ell(th: number, d: number) {
  const s = Math.sin(th), co = Math.cos(th), rx = RX + d, rz = (s < 0 ? RZF : RZB) + d;
  const nx = co / rx, nz = s / rz, l = Math.hypot(nx, nz);
  return {x: rx * co, z: CZ + rz * s, ry: Math.atan2(nx / l, nz / l)};
}
type Item = {p: [number, number, number]; ry: number; s: [number, number, number]; c: string};

const Boxes: React.FC<{items: Item[]; basic?: boolean}> = ({items, basic}) => {
  const ref = useRef<THREE.InstancedMesh>(null);
  useLayoutEffect(() => {
    const m = ref.current!, o = new THREE.Object3D(), col = new THREE.Color();
    items.forEach((it, i) => {
      o.position.set(...it.p); o.rotation.set(0, it.ry, 0); o.scale.set(...it.s); o.updateMatrix();
      m.setMatrixAt(i, o.matrix); m.setColorAt(i, col.set(it.c));
    });
    m.instanceMatrix.needsUpdate = true;
    if (m.instanceColor) m.instanceColor.needsUpdate = true;
  }, [items]);
  return (
    <instancedMesh ref={ref} args={[undefined, undefined, items.length]} frustumCulled={false} receiveShadow>
      <boxGeometry />
      {basic ? <meshBasicMaterial /> : <meshStandardMaterial roughness={0.9} />}
    </instancedMesh>
  );
};

const PAL = ['#e63946', '#f1faee', '#457b9d', '#ffb703', '#fb8500', '#8ecae6', '#ffffff', '#2a9d8f', '#e9c46a', '#6d597a'];
const SKIN = ['#f1c27d', '#e0ac69', '#c68642', '#8d5524', '#ffdbac'];

const Crowd: React.FC<{frame: number}> = ({frame}) => {
  const people = useMemo(() => {
    const r = rng(7), arr: {x: number; z: number; y: number; ry: number; c: string; sk: string; ph: number; amp: number}[] = [];
    for (let i = 0; i < N; i++) for (let k = 0; k < 4; k++) for (let row = 0; row < 2; row++) for (let j = 0; j < 6; j++) {
      const th = ((i + (j + 0.5 + (r() - 0.5) * 0.6) / 6) / N) * Math.PI * 2;
      const e = ell(th, 3 + 7.5 * k + 1.6 + row * 2.8 + r() * 0.5);
      arr.push({x: e.x, z: e.z, y: 4 + 3.2 * k + 0.4, ry: e.ry, c: PAL[Math.floor(r() * PAL.length)], sk: SKIN[Math.floor(r() * 5)], ph: r() * 6.28, amp: r() < 0.35 ? 0.3 : 0.03});
    }
    return arr;
  }, []);
  const body = useRef<THREE.InstancedMesh>(null), head = useRef<THREE.InstancedMesh>(null);
  useLayoutEffect(() => {
    const col = new THREE.Color();
    people.forEach((p, i) => { body.current!.setColorAt(i, col.set(p.c)); head.current!.setColorAt(i, col.set(p.sk)); });
    body.current!.instanceColor!.needsUpdate = true; head.current!.instanceColor!.needsUpdate = true;
  }, [people]);
  useLayoutEffect(() => {
    const o = new THREE.Object3D();
    people.forEach((p, i) => {
      const bob = Math.max(0, Math.sin(frame * 0.3 + p.ph)) * p.amp; // crowd waves / bounces
      o.rotation.set(0, p.ry, 0);
      o.position.set(p.x, p.y + bob, p.z); o.scale.set(0.55, 0.8, 0.4); o.updateMatrix(); body.current!.setMatrixAt(i, o.matrix);
      o.position.set(p.x, p.y + 0.6 + bob, p.z); o.scale.set(0.3, 0.3, 0.3); o.updateMatrix(); head.current!.setMatrixAt(i, o.matrix);
    });
    body.current!.instanceMatrix.needsUpdate = true; head.current!.instanceMatrix.needsUpdate = true;
  }, [frame, people]);
  return (
    <>
      <instancedMesh ref={body} args={[undefined, undefined, people.length]} frustumCulled={false}><boxGeometry /><meshStandardMaterial roughness={0.9} /></instancedMesh>
      <instancedMesh ref={head} args={[undefined, undefined, people.length]} frustumCulled={false}><sphereGeometry args={[0.5, 6, 5]} /><meshStandardMaterial roughness={0.8} /></instancedMesh>
    </>
  );
};

const Chalk: React.FC<{p: [number, number, number]; s: [number, number, number]; ry?: number}> = ({p, s, ry = 0}) => (
  <mesh position={p} rotation={[0, ry, 0]}><boxGeometry args={s} /><meshBasicMaterial color="#f8f8f8" /></mesh>
);
const HomePlate: React.FC<{x: number}> = ({x}) => (
  <group position={[x, 0, 0]}>
    <mesh position={[0, 0.03, 0]} receiveShadow><boxGeometry args={[0.43, 0.04, 0.43]} /><meshStandardMaterial color="#fff" /></mesh>
    {[-1, 1].map((sd) => (
      <group key={sd}>
        <Chalk p={[sd * 0.98, 0.035, 0.91]} s={[1.22, 0.02, 0.06]} /><Chalk p={[sd * 0.98, 0.035, -0.91]} s={[1.22, 0.02, 0.06]} />
        <Chalk p={[sd * 0.37, 0.035, 0]} s={[0.06, 0.02, 1.82]} /><Chalk p={[sd * 1.59, 0.035, 0]} s={[0.06, 0.02, 1.82]} />
      </group>
    ))}
  </group>
);

export const Stadium: React.FC<{frame: number; plates: number[]}> = ({frame, plates}) => {
  const {wall, stands} = useMemo(() => {
    const wall: Item[] = [], stands: Item[] = [], pal = ['#1d4ed8', '#dc2626', '#f5f5f5', '#facc15'];
    for (let i = 0; i < N; i++) {
      const th = (i / N) * Math.PI * 2, a = ell(th, 0), b = ell(th + (Math.PI * 2) / N, 0);
      const w = Math.hypot(b.x - a.x, b.z - a.z) * 1.18, inner = ell(th, -0.5);
      wall.push({p: [a.x, 1.6, a.z], ry: a.ry, s: [w, 3.2, 0.8], c: '#0d4a32'});
      wall.push({p: [a.x, 3.3, a.z], ry: a.ry, s: [w, 0.25, 0.9], c: '#facc15'});
      wall.push({p: [inner.x, 1.5, inner.z], ry: inner.ry, s: [w, 1.6, 0.1], c: pal[i % 4]}); // ad banners
      for (let k = 0; k < 4; k++) {
        const d = 3 + 7.5 * k + 3.7, e = ell(th, d), h = 4 + 3.2 * k;
        stands.push({p: [e.x, h / 2, e.z], ry: e.ry, s: [w * (1 + d / 72), h, 7.4], c: k % 2 ? '#26365c' : '#1f2a44'});
      }
    }
    return {wall, stands};
  }, []);

  const grass = useMemo(() => {
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const g = c.getContext('2d')!;
    g.fillStyle = '#2e8b3e'; g.fillRect(0, 0, 32, 64); g.fillStyle = '#37a049'; g.fillRect(32, 0, 32, 64);
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(50, 50); t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, []);
  const board = useMemo(() => {
    const c = document.createElement('canvas'); c.width = 1024; c.height = 256;
    const g = c.getContext('2d')!;
    g.fillStyle = '#0a1a4a'; g.fillRect(0, 0, 1024, 256);
    g.fillStyle = '#fbbf24'; g.font = 'bold 120px Impact, "Arial Black", sans-serif'; g.textAlign = 'center'; g.fillText('BASEBALL 101', 512, 150);
    g.fillStyle = '#fff'; g.font = 'bold 46px Arial'; g.fillText('HOME 3  -  VISITORS 2  -  BOTTOM 9', 512, 215);
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
  }, []);
  const stars = useMemo(() => {
    const r = rng(3), a = new Float32Array(600 * 3);
    for (let i = 0; i < 600; i++) { const th = r() * Math.PI * 2, ph = r() * 1.2 + 0.15, R = 380; a[i * 3] = R * Math.cos(th) * Math.cos(ph); a[i * 3 + 1] = R * Math.sin(ph); a[i * 3 + 2] = R * Math.sin(th) * Math.cos(ph); }
    return a;
  }, []);
  const towers = [0.5, 2.6, -0.4, -2.7, -1.1, -2.0].map((th) => ({...ell(th, 12), th}));
  const sb = ell(-2.0, -4);

  return (
    <group>
      <points><bufferGeometry><bufferAttribute attach="attributes-position" array={stars} count={600} itemSize={3} /></bufferGeometry><pointsMaterial color="#fff" size={2} sizeAttenuation={false} fog={false} /></points>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, -30]} receiveShadow><planeGeometry args={[600, 600]} /><meshStandardMaterial map={grass} roughness={1} /></mesh>
      {/* infield dirt, inner grass diamond, mound, home dirt */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.012, -18.4]} receiveShadow><circleGeometry args={[29, 64]} /><meshStandardMaterial color="#b5835a" roughness={1} /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, Math.PI / 4]} position={[0, 0.02, -19.4]} receiveShadow><planeGeometry args={[20, 20]} /><meshStandardMaterial color="#2f9a42" roughness={1} /></mesh>
      <mesh position={[0, 0.125, -18.4]} receiveShadow castShadow><cylinderGeometry args={[2.7, 3.2, 0.25, 40]} /><meshStandardMaterial color="#b5835a" roughness={1} /></mesh>
      <mesh position={[0, 0.27, -18.4]}><boxGeometry args={[0.6, 0.03, 0.15]} /><meshStandardMaterial color="#fff" /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.03, 0]} receiveShadow><circleGeometry args={[6, 48]} /><meshStandardMaterial color="#a8744b" roughness={1} /></mesh>
      {/* bases + foul lines */}
      {([[19.4, -19.4], [-19.4, -19.4], [0, -38.8]] as [number, number][]).map(([x, z], i) => (
        <mesh key={i} position={[x, 0.06, z]} rotation={[0, Math.PI / 4, 0]}><boxGeometry args={[0.4, 0.1, 0.4]} /><meshStandardMaterial color="#fff" /></mesh>
      ))}
      <Chalk p={[42.4, 0.04, -42.4]} s={[0.15, 0.02, 120]} ry={(3 * Math.PI) / 4} />
      <Chalk p={[-42.4, 0.04, -42.4]} s={[0.15, 0.02, 120]} ry={(-3 * Math.PI) / 4} />
      {plates.map((x) => <HomePlate key={x} x={x} />)}
      {/* backstop net */}
      <mesh position={[0, 5, 14]}><planeGeometry args={[26, 10, 52, 20]} /><meshBasicMaterial color="#8892b0" wireframe transparent opacity={0.35} /></mesh>
      {/* wall, stands, crowd */}
      <Boxes items={wall} basic /><Boxes items={stands} /><Crowd frame={frame} />
      {/* light towers */}
      {towers.map((t, i) => (
        <group key={i} position={[t.x, 0, t.z]}>
          <mesh position={[0, 24, 0]}><cylinderGeometry args={[0.6, 1, 48, 8]} /><meshStandardMaterial color="#555b6b" /></mesh>
          <mesh position={[0, 50, 0]} rotation={[0, t.ry + Math.PI, 0]}><boxGeometry args={[16, 9, 1]} /><meshBasicMaterial color="#fffbe6" toneMapped={false} /></mesh>
        </group>
      ))}
      {/* scoreboard */}
      <group position={[sb.x, 9, sb.z]} rotation={[0, sb.ry + Math.PI, 0]}>
        <mesh><planeGeometry args={[24, 6]} /><meshBasicMaterial map={board} toneMapped={false} /></mesh>
        {[-10, 10].map((x) => <mesh key={x} position={[x, -5, -0.3]}><boxGeometry args={[0.8, 8, 0.8]} /><meshStandardMaterial color="#333" /></mesh>)}
      </group>
    </group>
  );
};
