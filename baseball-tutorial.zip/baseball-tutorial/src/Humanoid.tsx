// Procedural low-poly athlete: torso/hips posed by parameters, arms & legs solved with 2-bone IK,
// so both hands always grip the bat and feet stay planted on the ground.
import React from 'react';
import * as THREE from 'three';
import {K} from './poses';
import {V3} from './timeline';

export interface Colors { jersey: string; pants: string; cap: string; skin: string; glove: string }
const UP = new THREE.Vector3(0, 1, 0);
const V = (a: V3) => new THREE.Vector3(a[0], a[1], a[2]);
const R = (q: THREE.Quaternion, x: number, y: number, z: number) => new THREE.Vector3(x, y, z).applyQuaternion(q);

function ik(root: THREE.Vector3, target: THREE.Vector3, l1: number, l2: number, pole: THREE.Vector3) {
  const d = target.clone().sub(root);
  let dist = d.length();
  const max = l1 + l2 - 0.002;
  if (dist > max) { d.setLength(max); dist = max; }
  if (dist < 0.05) { d.set(0, -0.05, 0); dist = 0.05; }
  const dir = d.clone().normalize();
  const a = (l1 * l1 - l2 * l2 + dist * dist) / (2 * dist);
  const h = Math.sqrt(Math.max(l1 * l1 - a * a, 0));
  const p = pole.clone().sub(dir.clone().multiplyScalar(pole.dot(dir))).normalize();
  return {mid: root.clone().add(dir.clone().multiplyScalar(a)).add(p.multiplyScalar(h)), end: root.clone().add(d)};
}

const Limb: React.FC<{a: THREE.Vector3; b: THREE.Vector3; r: number; color: string}> = ({a, b, r, color}) => {
  const d = b.clone().sub(a);
  const q = new THREE.Quaternion().setFromUnitVectors(UP, d.clone().normalize());
  return (
    <mesh position={a.clone().add(b).multiplyScalar(0.5)} quaternion={q} castShadow>
      <capsuleGeometry args={[r, Math.max(d.length() - 2 * r, 0.01), 4, 10]} />
      <meshStandardMaterial color={color} roughness={0.75} />
    </mesh>
  );
};

export const Humanoid: React.FC<{k: K; lh: V3; rh: V3; bat?: {grip: V3; dir: V3}; c: Colors; helmet?: boolean; glove?: boolean}> =
({k, lh, rh, bat, c, helmet, glove}) => {
  const pel = new THREE.Vector3(k.px, k.py, k.pz);
  const qP = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, k.pyaw, 0));
  const qC = new THREE.Quaternion().setFromEuler(new THREE.Euler(k.lean, k.cyaw, k.tilt, 'YXZ'));
  const qH = new THREE.Quaternion().setFromEuler(new THREE.Euler(k.hpit, k.hyaw, 0, 'YXZ'));
  const base = pel.clone().add(new THREE.Vector3(0, 0.08, 0));
  const hipL = pel.clone().add(R(qP, 0.1, 0, 0)), hipR = pel.clone().add(R(qP, -0.1, 0, 0));
  const shL = base.clone().add(R(qC, 0.2, 0.5, 0)), shR = base.clone().add(R(qC, -0.2, 0.5, 0));
  const neck = base.clone().add(R(qC, 0, 0.58, 0));
  const head = neck.clone().add(R(qH, 0, 0.13, 0)).add(new THREE.Vector3(k.hx, 0, k.hz));

  const yl = 0.3 * k.pyaw, yr = 0.8 * k.pyaw; // front foot barely turns, back foot pivots
  const fl = new THREE.Vector3(k.lfx, k.lfy + 0.075, k.lfz), fr = new THREE.Vector3(k.rfx, k.rfy + 0.075, k.rfz);
  const legL = ik(hipL, fl, 0.48, 0.47, new THREE.Vector3(Math.sin(yl) + 0.3, 0.1, Math.cos(yl)));
  const legR = ik(hipR, fr, 0.48, 0.47, new THREE.Vector3(Math.sin(yr) - 0.3, 0.1, Math.cos(yr)));
  const armL = ik(shL, V(lh), 0.29, 0.27, R(qC, 0.6, -1, -0.3));
  const armR = ik(shR, V(rh), 0.29, 0.27, R(qC, -0.6, -1, -0.3));

  const shoe = (p: THREE.Vector3, y: number) => (
    <mesh position={[p.x + Math.sin(y) * 0.05, p.y - 0.04, p.z + Math.cos(y) * 0.05]} rotation={[0, y, 0]} castShadow>
      <boxGeometry args={[0.11, 0.07, 0.28]} /><meshStandardMaterial color="#15151a" roughness={0.6} />
    </mesh>
  );
  const batMesh = bat && (() => {
    const dir = V(bat.dir).normalize(), g = V(bat.grip);
    const q = new THREE.Quaternion().setFromUnitVectors(UP, dir);
    return (
      <mesh position={g.clone().add(dir.clone().multiplyScalar(0.85 / 2 - 0.1))} quaternion={q} castShadow>
        <cylinderGeometry args={[0.038, 0.014, 0.85, 14]} /><meshStandardMaterial color="#c9955c" roughness={0.4} />
      </mesh>
    );
  })();

  return (
    <group>
      {/* legs */}
      <Limb a={hipL} b={legL.mid} r={0.085} color={c.pants} /><Limb a={legL.mid} b={legL.end} r={0.065} color={c.pants} />
      <Limb a={hipR} b={legR.mid} r={0.085} color={c.pants} /><Limb a={legR.mid} b={legR.end} r={0.065} color={c.pants} />
      {shoe(legL.end, yl)}{shoe(legR.end, yr)}
      {/* hips + torso */}
      <mesh position={pel} quaternion={qP} castShadow><boxGeometry args={[0.36, 0.2, 0.22]} /><meshStandardMaterial color={c.pants} roughness={0.8} /></mesh>
      <mesh position={base.clone().add(R(qC, 0, 0.29, 0))} quaternion={qC} scale={[1.4, 1, 0.85]} castShadow>
        <capsuleGeometry args={[0.14, 0.3, 4, 12]} /><meshStandardMaterial color={c.jersey} roughness={0.7} />
      </mesh>
      {/* arms */}
      <Limb a={shL} b={armL.mid} r={0.058} color={c.jersey} /><Limb a={armL.mid} b={armL.end} r={0.045} color={c.skin} />
      <Limb a={shR} b={armR.mid} r={0.058} color={c.jersey} /><Limb a={armR.mid} b={armR.end} r={0.045} color={c.skin} />
      <mesh position={armL.end} castShadow><sphereGeometry args={[glove ? 0.09 : 0.055, 10, 10]} /><meshStandardMaterial color={glove ? c.glove : '#111'} /></mesh>
      <mesh position={armR.end} castShadow><sphereGeometry args={[0.055, 10, 10]} /><meshStandardMaterial color="#111" /></mesh>
      {batMesh}
      {/* neck + head */}
      <Limb a={neck} b={head} r={0.05} color={c.skin} />
      <group position={head} quaternion={qH}>
        <mesh castShadow><sphereGeometry args={[0.12, 16, 14]} /><meshStandardMaterial color={c.skin} roughness={0.7} /></mesh>
        <mesh position={[0, 0.01, 0]} castShadow><sphereGeometry args={[0.132, 18, 12, 0, Math.PI * 2, 0, Math.PI * 0.55]} /><meshStandardMaterial color={c.cap} roughness={helmet ? 0.3 : 0.8} /></mesh>
        <mesh position={[0, 0.0, 0.13]} rotation={[0.15, 0, 0]}><boxGeometry args={[helmet ? 0.15 : 0.17, 0.014, 0.1]} /><meshStandardMaterial color={c.cap} /></mesh>
        <mesh position={[0.045, 0.01, 0.108]}><sphereGeometry args={[0.014, 6, 6]} /><meshBasicMaterial color="#111" /></mesh>
        <mesh position={[-0.045, 0.01, 0.108]}><sphereGeometry args={[0.014, 6, 6]} /><meshBasicMaterial color="#111" /></mesh>
      </group>
    </group>
  );
};
