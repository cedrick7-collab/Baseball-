import {Config} from '@remotion/cli/config';

Config.setVideoImageFormat('jpeg');
Config.setCodec('h264');
Config.setChromiumOpenGlRenderer('angle'); // WebGL for Three.js when rendering headless
Config.setOverwriteOutput(true);
